package com.example.traversenepal_screen1;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SliderAdapter extends PagerAdapter {
    Context context;
    LayoutInflater LayoutInflater;
    private Object ConstraintLayout;

    public SliderAdapter(Context context)
    {
        this.context = context;

    }

    public int

    public int getCount() {
        return 0;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position)
    {
        LayoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view;
        boolean attachToRoot;
        view = LayoutInflater.inflate(R.layout.fragment_frag__help__screen_1,container, attachToRoot): false );

@Override
        public void destroyItem(ViewGroup container, int position, Object object);
        container.removeView(ConstraintLayout);
    }
}
